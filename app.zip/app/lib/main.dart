import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:hidden_drawer_menu/hidden_drawer_menu.dart';
import 'package:seapp/app/share/views/barco_add_view.dart';
import 'package:seapp/app/share/views/barco_view.dart';
import 'package:seapp/app/share/views/configuracao_view.dart';
import 'package:seapp/app/share/views/inicio_view.dart';
import 'package:seapp/app/share/views/percurso_view.dart';
import 'package:seapp/app/share/views/viaje_view.dart';

void main() async {
  //WidgetsFlutterBinding.ensureInitialized();
  runApp(MyApp());
  //TesteMain.repository();
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.indigo,

      ),
      home: MyHomePage(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  MyHomePage({Key key}) : super(key: key);

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  List<ScreenHiddenDrawer> itens = [];
  MainState state = MainState.inicio;
  TextStyle style =
      TextStyle(color: Colors.white.withOpacity(0.8), fontSize: 20.0);

  @override
  void initState() {
    itens.add(new ScreenHiddenDrawer(
      new ItemHiddenMenu(
          name: "Inicio",
          baseStyle: style,
          colorLineSelected: Colors.white,
          onTap: () {
            setState(() {
              state = MainState.inicio;
            });
          }),
      InicioView(),
    ));

    itens.add(new ScreenHiddenDrawer(
        new ItemHiddenMenu(
            name: "Barco",
            baseStyle: style,
            colorLineSelected: Colors.white,
            onTap: () {
              setState(() {
                state = MainState.barco;
              });
            }),
        BarcoView()));

    itens.add(new ScreenHiddenDrawer(
        new ItemHiddenMenu(
            name: "Viaje",
            baseStyle: style,
            colorLineSelected: Colors.white,
            onTap: () {
              setState(() {
                state = MainState.viaje;
              });
            }),
        ViajeView()));

    itens.add(new ScreenHiddenDrawer(
        new ItemHiddenMenu(
            name: "Percurso",
            baseStyle: style,
            colorLineSelected: Colors.white,
            onTap: () {
              setState(() {
                state = MainState.percurso;
              });
            }),
        PercursoView()));

    itens.add(new ScreenHiddenDrawer(
        new ItemHiddenMenu(
            name: "Configuração",
            baseStyle: style,
            colorLineSelected: Colors.white,
            onTap: () {
              setState(() {
                state = MainState.configuracao;
              });
            }),
        ConfiguracaoView()));

    itens.add(new ScreenHiddenDrawer(
        new ItemHiddenMenu(
          name: "Sair",
          baseStyle: style,
          colorLineSelected: Colors.red,
          onTap: () => exit(0),
        ),
        null));
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return HiddenDrawerMenu(
      backgroundColorMenu: Colors.indigo[900],
      backgroundMenu: DecorationImage(
        image: ExactAssetImage("assets/images/back.jpg"),
        fit: BoxFit.cover,
        colorFilter:
            ColorFilter.mode(Color.fromRGBO(0, 0, 0, 0.4), BlendMode.dstATop),
      ),
      screens: itens,
      actionsAppBar: btAdd(context),
      //    typeOpen: TypeOpen.FROM_RIGHT,
      //    disableAppBarDefault: false,
      //    enableScaleAnimin: true,
      //    enableCornerAnimin: true,
      //    slidePercent: 80.0,
      //    verticalScalePercent: 80.0,
      //    contentCornerRadius: 10.0,
      //    leadingAppBar: Icon(Icons.menu_sharp, color: Colors.black),
      //    backgroundContent: DecorationImage((image: ExactAssetImage('assets/bg_news.jpg'),fit: BoxFit.cover),
      //    whithAutoTittleName: true,
      //    styleAutoTittleName: TextStyle(color: Colors.red),
      //    actionsAppBar: <Widget>[],
      //    backgroundColorContent: Colors.blue,
      //    elevationAppBar: 4.0,
      //    tittleAppBar: Center(child: Icon(Icons.ac_unit),),
      //    enableShadowItensMenu: true,
      //    backgroundMenu: DecorationImage(image: ExactAssetImage('assets/bg_news.jpg'),fit: BoxFit.cover),
    );
  }

  List<Widget> btAdd(context) {
    switch (state) {
      case MainState.barco:
        return [
          IconButton(
            icon: Icon(Icons.add),
            onPressed: () => btAddBarco(context),
          )
        ];
      case MainState.viaje:
        return [
          IconButton(
              icon: Icon(Icons.add), onPressed: () => btAddViaje(context)),
        ];
      case MainState.percurso:
        return [
          IconButton(
              icon: Icon(Icons.add), onPressed: () => btAddPercuso(context)),
        ];
      default:
        return [];
    }
  }

  btAddBarco(BuildContext context) async {
    final result = await Navigator.push(
        context, MaterialPageRoute(builder: (context) => BarcoAddView()));
    if (result == "new") setState(() {});
  }

  btAddViaje(BuildContext context) async {
    final result = await Navigator.push(
        context, MaterialPageRoute(builder: (context) => BarcoAddView()));
    if (result == "new") setState(() {});
  }

  btAddPercuso(BuildContext context) async {
    final result = await Navigator.push(
        context, MaterialPageRoute(builder: (context) => BarcoAddView()));
    if (result == "new") setState(() {});
  }
}

enum MainState { inicio, barco, viaje, percurso, configuracao }
