import 'package:flutter/material.dart';
import 'package:seapp/app/domain/models/barco_model.dart';
import 'package:seapp/app/share/controllers/barco_controller.dart';

class BarcoAddView extends StatefulWidget {
  @override
  _BarcoAddViewState createState() => _BarcoAddViewState();
}

class _BarcoAddViewState extends State<BarcoAddView> {
  BarcoController con = BarcoController();
  BarcoModel barco = BarcoModel();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Barco - Novo"),
      ),
      body: Container(
        width: MediaQuery.of(context).size.width,
        height: MediaQuery.of(context).size.height,
        child: ListView(
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 5),
              child: TextField(
                onChanged: (text) => barco.nome = text,
                keyboardType: TextInputType.name,
                decoration: InputDecoration(
                  labelText: "Nome de Embarcação:",
                  border: OutlineInputBorder(),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 5),
              child: TextField(
                onChanged: (text) => barco.tipo = text,
                keyboardType: TextInputType.text,
                decoration: InputDecoration(
                  labelText: "Tipo de Embarcação:",
                  border: OutlineInputBorder(),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 5),
              child: TextField(
                onChanged: (text) => barco.peso = double.tryParse(text) ?? 0,
                keyboardType: TextInputType.number,
                decoration: InputDecoration(
                  labelText: "Peso da Embarcação:",
                  border: OutlineInputBorder(),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 5),
              child: TextField(
                onChanged: (text) =>
                    barco.potencia = double.tryParse(text) ?? 0,
                keyboardType: TextInputType.number,
                decoration: InputDecoration(
                  labelText: "Potencia do Motor:",
                  border: OutlineInputBorder(),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 5),
              child: Column(
                children: [
                  TextField(
                    onChanged: (text) =>
                        barco.combustivel = double.tryParse(text) ?? 0,
                    keyboardType: TextInputType.number,
                    decoration: InputDecoration(
                      labelText: "Consumo de combustivel por hora:",
                      border: OutlineInputBorder(),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
      floatingActionButton: CircleAvatar(
        radius: 25,
        backgroundColor: Colors.indigo,
        child: IconButton(
            icon: Icon(Icons.save),
            color: Colors.white,
            onPressed: () {
              String valid = con.valid(barco);
              if (valid.isEmpty) {
                con.save(barco);
                Navigator.pop(context, 'new');
              } else {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text("$valid"),
                  ),
                );
              }
            }),
      ),
    );
  }
}
