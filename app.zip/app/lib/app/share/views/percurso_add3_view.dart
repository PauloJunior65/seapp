import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:seapp/app/share/controllers/percurso_view_controller.dart';

class PecursoAdd3View extends StatefulWidget {
  final PercursoViewController con = PercursoViewController();

  @override
  _PecursoAdd3ViewState createState() => _PecursoAdd3ViewState();
}

class _PecursoAdd3ViewState extends State<PecursoAdd3View> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Percurso - Novo"),
      ),
      body: Container(
        width: MediaQuery.of(context).size.width,
        height: MediaQuery.of(context).size.height,
        child: ListView(
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 3),
              child: Column(
                children: [
                  TextField(
                    controller: TextEditingController(
                        text: widget.con.percurso.distancia.toString()),
                    onChanged: (text) => setState(() => widget
                            .con.percurso.distancia =
                        double.parse(text) ?? widget.con.percurso.distancia),
                    keyboardType: TextInputType.name,
                    decoration: InputDecoration(
                      labelText: "Distancia: (metros)",
                      border: OutlineInputBorder(),
                    ),
                  ),
                  Text(
                    "${(widget.con.percurso.distancia / 1000).toStringAsFixed(1)} Km",
                    textAlign: TextAlign.end,
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 3),
              child: Column(
                children: [
                  TextField(
                    controller: TextEditingController(
                        text: widget.con.percurso.velocidade.toString()),
                    onChanged: (text) => setState(() => widget
                            .con.percurso.velocidade =
                        double.parse(text) ?? widget.con.percurso.velocidade),
                    keyboardType: TextInputType.text,
                    decoration: InputDecoration(
                      labelText: "Velocidade: ( m/s )",
                      border: OutlineInputBorder(),
                    ),
                  ),
                  Text(
                    "${(widget.con.percurso.velocidade * 3.6).toStringAsFixed(1)} km/h",
                    textAlign: TextAlign.end,
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 3),
              child: Column(
                children: [
                  TextField(
                    controller: TextEditingController(
                        text: widget.con.percurso.combustivel.toString()),
                    onChanged: (text) => widget.con.percurso.combustivel =
                        double.tryParse(text) ?? 0,
                    keyboardType: TextInputType.number,
                    decoration: InputDecoration(
                      labelText: "Combustivel Gasto: ( litros consumidos )",
                      border: OutlineInputBorder(),
                    ),
                  ),
                  Text(
                    "Estimativa da Emissão: ${(widget.con.percurso.combustivel * 3.33).toStringAsFixed(1)} a ${(widget.con.percurso.combustivel * 3.41).toStringAsFixed(1)} KgCO2/litro",
                    textAlign: TextAlign.end,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
