import 'package:flutter/material.dart';
import 'package:seapp/app/domain/models/percurso_model.dart';
import 'package:seapp/app/share/controllers/percurso_controller.dart';

class PercursoView extends StatefulWidget {
  @override
  _PercursoViewState createState() => _PercursoViewState();
}

class _PercursoViewState extends State<PercursoView> {
  PercursoController con = PercursoController();

  @override
  Widget build(BuildContext context) {
    return Container(
      width: MediaQuery.of(context).size.width,
      height: MediaQuery.of(context).size.height,
      child: FutureBuilder(
          future: con.load(),
          builder: (context, snapshot) {
            if (snapshot.hasData) {
              return list(snapshot.data);
            }
            return Center(
              child: CircularProgressIndicator(),
            );
          }),
    );
  }

  list(List<PercursoModel> list) {
    return ListView.builder(
        itemCount: list.length,
        itemBuilder: (context, index) {
          PercursoModel percurso = list[index];
          return Padding(
            padding: EdgeInsets.fromLTRB(5, 2, 5, 2),
            child: Card(
              child: Stack(
                children: [
                  Center(
                    child: Image.asset(
                      "assets/images/map.png",
                      width: 45,
                      height: 45,
                      color: Color.fromRGBO(0, 0, 0, 0.1),
                    ),
                  ),
                  Column(
                    children: [
                      Padding(
                        padding: EdgeInsets.only(top: 5),
                        child: Container(
                          width: MediaQuery.of(context).size.width - 40,
                          child: Text(
                            "# ${percurso.id} \n Distancia: ${percurso.distancia} \n Velocidade: ${percurso.velocidade} \n Barco: ${percurso.barco.nome} \n Origem: ${percurso.viaje.origem} \n Destino: ${percurso.viaje.destino}",
                            style: TextStyle(fontSize: 12.0),
                            textAlign: TextAlign.start,
                          ),
                        ),
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          IconButton(
                            icon: const Icon(Icons.search),
                            onPressed: () {
                              //Ver
                              //Navigator.push(context, null);
                            },
                            iconSize: 18.0,
                            color: Color.fromRGBO(0, 0, 255, 1),
                          ),
                          IconButton(
                            icon: const Icon(Icons.mode_edit),
                            onPressed: () {
                              //Editar
                              //Navigator.push(context, null);
                            },
                            iconSize: 18.0,
                            color: Color.fromRGBO(255, 255, 0, 1),
                          ),
                          IconButton(
                            icon: const Icon(Icons.delete_forever),
                            onPressed: () {
                              //Deletar
                              //Navigator.push(context, null);
                            },
                            iconSize: 18.0,
                            color: Color.fromRGBO(255, 0, 0, 1),
                          ),
                        ],
                      ),
                    ],
                  ),
                ],
              ),
            ),
          );
        });
  }
}
