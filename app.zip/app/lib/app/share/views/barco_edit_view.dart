import 'package:flutter/material.dart';
import 'package:seapp/app/domain/models/barco_model.dart';
import 'package:seapp/app/share/controllers/barco_controller.dart';

class BarcoEditView extends StatefulWidget {
  final BarcoController con = BarcoController();
  final BarcoModel barco;

  BarcoEditView({Key key, @required this.barco}) : super(key: key);

  @override
  _BarcoEditViewState createState() => _BarcoEditViewState();
}

class _BarcoEditViewState extends State<BarcoEditView> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Barco - Editar"),
      ),
      body: Container(
        width: MediaQuery.of(context).size.width,
        height: MediaQuery.of(context).size.height,
        child: ListView(
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 3),
              child: TextField(
                controller: TextEditingController(text: widget.barco.nome),
                onChanged: (text) => widget.barco.nome = text,
                keyboardType: TextInputType.name,
                decoration: InputDecoration(
                  labelText: "Nome de Embarcação:",
                  border: OutlineInputBorder(),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 3),
              child: TextField(
                controller: TextEditingController(text: widget.barco.tipo),
                onChanged: (text) => widget.barco.tipo = text,
                keyboardType: TextInputType.text,
                decoration: InputDecoration(
                  labelText: "Tipo de Embarcação:",
                  border: OutlineInputBorder(),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 3),
              child: TextField(
                controller:
                    TextEditingController(text: widget.barco.peso.toString()),
                onChanged: (text) =>
                    widget.barco.peso = double.tryParse(text) ?? 0,
                keyboardType: TextInputType.number,
                decoration: InputDecoration(
                  labelText: "Peso da Embarcação:",
                  border: OutlineInputBorder(),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 3),
              child: TextField(
                controller: TextEditingController(
                    text: widget.barco.potencia.toString()),
                onChanged: (text) =>
                    widget.barco.potencia = double.tryParse(text) ?? 0,
                keyboardType: TextInputType.number,
                decoration: InputDecoration(
                  labelText: "Potencia do Motor:",
                  border: OutlineInputBorder(),
                ),
              ),
            ),
          ],
        ),
      ),
      floatingActionButton: IconButton(
          icon: Icon(Icons.save),
          onPressed: () {
            String valid = widget.con.valid(widget.barco);
            if (valid.isEmpty) {
              widget.con.save(widget.barco);
              Navigator.pop(context, 'save');
            } else {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text(valid),
                ),
              );
            }
          }),
    );
  }
}
