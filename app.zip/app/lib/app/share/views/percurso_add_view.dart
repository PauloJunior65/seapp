import 'package:flutter/material.dart';
import 'package:seapp/app/domain/models/barco_model.dart';
import 'package:seapp/app/domain/models/viaje_model.dart';
import 'package:seapp/app/share/controllers/percurso_view_controller.dart';

class PecursoAddView extends StatefulWidget {
  final PercursoViewController con = PercursoViewController();

  @override
  _PecursoAddViewState createState() => _PecursoAddViewState();
}

class _PecursoAddViewState extends State<PecursoAddView> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Percurso - Novo"),
      ),
      body: Container(
        width: MediaQuery.of(context).size.width,
        height: MediaQuery.of(context).size.height,
        child: FutureBuilder(
            future: widget.con.load(),
            builder: (context, snapshot) {
              if (snapshot.hasData) {
                return view(context, snapshot);
              }
              return Center(
                child: CircularProgressIndicator(),
              );
            }),
      ),
    );
  }

  view(context, AsyncSnapshot<dynamic> snapshot) {
    List<BarcoModel> listbarco = snapshot.data['barco'];
    List<ViajeModel> listviaje = snapshot.data['viaje'];
    return ListView(
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 3),
          child: Row(
            children: [
              Text("Barco:"),
              DropdownButton(
                onChanged: (BarcoModel newValue) => setState(() {
                  widget.con.percurso.barco = newValue;
                  widget.con.percurso.barcoId = newValue.id;
                }),
                items: listbarco
                    .map<DropdownMenuItem<BarcoModel>>((BarcoModel value) {
                  return DropdownMenuItem<BarcoModel>(
                    value: value,
                    child: Text("${value.nome}, ID:${value.id}"),
                  );
                }).toList(),
              ),
            ],
          ),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 3),
          child: Row(
            children: [
              Text("Viaje:"),
              DropdownButton(
                onChanged: (ViajeModel newValue) => setState(() {
                  widget.con.percurso.viaje = newValue;
                  widget.con.percurso.viajeId = newValue.id;
                }),
                items: widget.con
                    .listViaje(listviaje)
                    .map<DropdownMenuItem<ViajeModel>>((ViajeModel value) {
                  return DropdownMenuItem<ViajeModel>(
                    value: value,
                    child: Text(
                        "(${value.origem},${value.destino}) ID:${value.id}"),
                  );
                }).toList(),
              ),
            ],
          ),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 3),
          child: TextField(
            onChanged: (text) =>
                widget.con.percurso.adulto = int.parse(text) ?? 0,
            keyboardType: TextInputType.number,
            decoration: InputDecoration(
              labelText: "Adulto:",
              border: OutlineInputBorder(),
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 3),
          child: TextField(
            onChanged: (text) =>
                widget.con.percurso.crianca = int.parse(text) ?? 0,
            keyboardType: TextInputType.name,
            decoration: InputDecoration(
              labelText: "Criaça:",
              border: OutlineInputBorder(),
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 3),
          child: RaisedButton(
            onPressed: () {},
            color: Colors.indigo,
            textColor: Colors.white,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.zero,
              side: BorderSide(color: Colors.indigo),
            ),
            child: Text(
              "Avança",
              style: TextStyle(fontSize: 18),
            ),
          ),
        ),
      ],
    );
  }
}
