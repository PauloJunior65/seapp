import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong/latlong.dart';
import 'package:seapp/app/domain/models/ponto_model.dart';
import 'package:seapp/app/share/controllers/percurso_view_controller.dart';

class PecursoAdd2View extends StatefulWidget {
  final PercursoViewController con;

  PecursoAdd2View({Key key, @required this.con}) : super(key: key);

  @override
  _PecursoAdd2ViewState createState() => _PecursoAdd2ViewState();
}

class _PecursoAdd2ViewState extends State<PecursoAdd2View> {
  bool isloop = true;

  @override
  void initState() {
    super.initState();
    if (isloop) Future.sync(() => loop());
  }

  loop() {
    widget.con.datetime = DateTime.now();
    int count = 0;
    while (isloop) {
      setState(() async {
        if (count == 0) {
          await widget.con.update(true);
        } else
          await widget.con.update(false);
      });
      count++;
      if (count == 2) count = 0;
      Future.delayed(Duration(seconds: 1));
    }
  }

  finalizar() async {
    isloop = false;
    await widget.con.update(true);
    await widget.con.calcular();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Percurso - Novo"),
      ),
      body: Container(
        width: MediaQuery.of(context).size.width,
        height: MediaQuery.of(context).size.height,
        child: ListView(
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 3),
              child: RaisedButton(
                onPressed: () {},
                color: Colors.indigo,
                textColor: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.zero,
                  side: BorderSide(color: Colors.indigo),
                ),
                child: Text(
                  "Finalizar",
                  style: TextStyle(fontSize: 18),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 3),
              child: Card(
                child: Text(
                  "Tempo: ${widget.con.tempo()} \nDistancia: ${widget.con.percurso.distancia.toStringAsFixed(2)} m \nVelocidade: ${widget.con.percurso.velocidade.toStringAsFixed(0)} K/h",
                  style: TextStyle(fontSize: 18),
                ),
              ),
            ),
            FlutterMap(
              options: MapOptions(
                center: LatLng(30, 30),
                zoom: 13.0,
              ),
              layers: [
                TileLayerOptions(
                    urlTemplate:
                        "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",
                    subdomains: ['a', 'b', 'c']),
                MarkerLayerOptions(
                  markers:
                      List.generate(widget.con.percurso.pontos.length, (index) {
                    PontoModel ponto = widget.con.percurso.pontos[index];
                    return Marker(
                      width: 80.0,
                      height: 80.0,
                      point: LatLng(ponto.latitude, ponto.longitude),
                      builder: (ctx) => Container(
                        child: FlutterLogo(),
                      ),
                    );
                  }),
                ),
              ],
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 3),
              child: Column(
                children:
                    List.generate(widget.con.percurso.pontos.length, (index) {
                  index = widget.con.percurso.pontos.length - index;
                  PontoModel ponto = widget.con.percurso.pontos[index];
                  DateTime datetime = DateTime.parse(ponto.datetime);
                  return Padding(
                    padding: const EdgeInsets.only(bottom: 3),
                    child: Card(
                      child: Text(
                        "# $index \nTime: ${datetime.hour}:${datetime.minute}:${datetime.second} \nLongitude: ${ponto.longitude} \nLatitude: ${ponto.latitude}",
                        style: TextStyle(fontSize: 12.0),
                        textAlign: TextAlign.start,
                      ),
                    ),
                  );
                }),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
