import 'package:flutter/material.dart';
import 'package:seapp/app/domain/models/barco_model.dart';
import 'package:seapp/app/domain/models/percurso_model.dart';
import 'package:seapp/app/domain/models/viaje_model.dart';
import 'package:seapp/app/share/controllers/percurso_controller.dart';

class PercursoEditView extends StatefulWidget {
  final PercursoController con = PercursoController();
  final PercursoModel percurso;

  PercursoEditView({Key key, @required this.percurso}) : super(key: key);

  @override
  _PercursoEditViewState createState() => _PercursoEditViewState();
}

class _PercursoEditViewState extends State<PercursoEditView> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Percurso - Editar"),
      ),
      body: Container(
        width: MediaQuery.of(context).size.width,
        height: MediaQuery.of(context).size.height,
        child: FutureBuilder(
            future: widget.con.loadBarcoViaje(),
            builder: (context, snapshot) {
              List<BarcoModel> listbarco = snapshot.data['barco'];
              BarcoModel barco;
              for (var b in listbarco) {
                if (b.id == widget.percurso.barcoId) {
                  widget.percurso.barco = b;
                  barco = b;
                  break;
                }
              }
              List<ViajeModel> listviaje = snapshot.data['viaje'];
              ViajeModel viaje;
              for (var v in listviaje) {
                if (v.id == widget.percurso.viajeId) {
                  widget.percurso.viaje = v;
                  viaje = v;
                  break;
                }
              }
              return ListView(
                children: [
                  Padding(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 5, vertical: 3),
                    child: Row(
                      children: [
                        Text("Barco:"),
                        DropdownButton(
                          onChanged: (BarcoModel newValue) => setState(() {
                            widget.percurso.barco = newValue;
                            widget.percurso.barcoId = newValue.id;
                          }),
                          items: listbarco.map<DropdownMenuItem<BarcoModel>>(
                              (BarcoModel value) {
                            return DropdownMenuItem<BarcoModel>(
                              value: value,
                              child: Text("${value.nome}, ID:${value.id}"),
                            );
                          }).toList(),
                          value: barco,
                        ),
                      ],
                    ),
                  ),
                  Padding(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 5, vertical: 3),
                    child: Row(
                      children: [
                        Text("Viaje:"),
                        DropdownButton(
                          onChanged: (ViajeModel newValue) => setState(() {
                            widget.percurso.viaje = newValue;
                            widget.percurso.viajeId = newValue.id;
                          }),
                          items: widget.con
                              .listViaje(listviaje, widget.percurso)
                              .map<DropdownMenuItem<ViajeModel>>(
                                  (ViajeModel value) {
                            return DropdownMenuItem<ViajeModel>(
                              value: value,
                              child: Text(
                                  "(${value.origem},${value.destino}) ID:${value.id}"),
                            );
                          }).toList(),
                          value: viaje,
                        ),
                      ],
                    ),
                  ),
                  Padding(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 5, vertical: 3),
                    child: TextField(
                      controller: TextEditingController(
                          text: widget.percurso.adulto.toString()),
                      onChanged: (text) =>
                          widget.percurso.adulto = int.parse(text) ?? 0,
                      keyboardType: TextInputType.number,
                      decoration: InputDecoration(
                        labelText: "Adulto:",
                        border: OutlineInputBorder(),
                      ),
                    ),
                  ),
                  Padding(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 5, vertical: 3),
                    child: TextField(
                      controller: TextEditingController(
                          text: widget.percurso.crianca.toString()),
                      onChanged: (text) =>
                          widget.percurso.crianca = int.parse(text) ?? 0,
                      keyboardType: TextInputType.name,
                      decoration: InputDecoration(
                        labelText: "Criaça:",
                        border: OutlineInputBorder(),
                      ),
                    ),
                  ),
                  Padding(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 5, vertical: 3),
                    child: Column(
                      children: [
                        TextField(
                          controller: TextEditingController(
                              text: widget.percurso.distancia.toString()),
                          onChanged: (text) => setState(() => widget
                                  .percurso.distancia =
                              double.parse(text) ?? widget.percurso.distancia),
                          keyboardType: TextInputType.name,
                          decoration: InputDecoration(
                            labelText: "Distancia: (metros)",
                            border: OutlineInputBorder(),
                          ),
                        ),
                        Text(
                          "${(widget.percurso.distancia / 1000).toStringAsFixed(1)} Km",
                          textAlign: TextAlign.end,
                        ),
                      ],
                    ),
                  ),
                  Padding(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 5, vertical: 3),
                    child: Column(
                      children: [
                        TextField(
                          controller: TextEditingController(
                              text: widget.percurso.velocidade.toString()),
                          onChanged: (text) => setState(() => widget
                                  .percurso.velocidade =
                              double.parse(text) ?? widget.percurso.velocidade),
                          keyboardType: TextInputType.text,
                          decoration: InputDecoration(
                            labelText: "Velocidade: ( m/s )",
                            border: OutlineInputBorder(),
                          ),
                        ),
                        Text(
                          "${(widget.percurso.velocidade * 3.6).toStringAsFixed(1)} km/h",
                          textAlign: TextAlign.end,
                        ),
                      ],
                    ),
                  ),
                  Padding(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 5, vertical: 3),
                    child: Column(
                      children: [
                        TextField(
                          onChanged: (text) => widget.percurso.combustivel =
                              double.tryParse(text) ?? 0,
                          keyboardType: TextInputType.number,
                          decoration: InputDecoration(
                            labelText:
                                "Combustivel Gasto: ( litros consumidos )",
                            border: OutlineInputBorder(),
                          ),
                        ),
                        Text(
                          "Estimativa da Emissão: ${(widget.percurso.combustivel * 3.33).toStringAsFixed(1)} a ${(widget.percurso.combustivel * 3.41).toStringAsFixed(1)} KgCO2/litro",
                          textAlign: TextAlign.end,
                        ),
                      ],
                    ),
                  ),
                  Padding(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 5, vertical: 3),
                    child: RaisedButton(
                      onPressed: () {},
                      color: Colors.indigo,
                      textColor: Colors.white,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.zero,
                        side: BorderSide(color: Colors.indigo),
                      ),
                      child: Text(
                        "Salvar",
                        style: TextStyle(fontSize: 18),
                      ),
                    ),
                  ),
                ],
              );
            }),
      ),
    );
  }
}
