import 'package:flutter/material.dart';
import 'package:seapp/app/share/controllers/viaje_controller.dart';

class ViajeAddListView extends StatefulWidget {
  @override
  _ViajeAddListViewState createState() => _ViajeAddListViewState();
}

class _ViajeAddListViewState extends State<ViajeAddListView> {
  ViajeController con = ViajeController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Viaje - Lista"),
      ),
      body: Container(
        width: MediaQuery.of(context).size.width,
        height: MediaQuery.of(context).size.height,
        child: FutureBuilder(
            future: con.listNomes(),
            builder: (context, snapshot) {
              if (snapshot.hasData) {
                return list(snapshot.data);
              }
              return Center(
                child: CircularProgressIndicator(),
              );
            }),
      ),
    );
  }

  list(List<String> list) {
    return ListView.builder(
        itemCount: list.length,
        itemBuilder: (context, index) {
          String nome = list[index];
          return Padding(
              padding: EdgeInsets.fromLTRB(5, 2, 5, 2),
              child: GestureDetector(
                child: Card(
                  child: Text(
                    nome,
                    style: TextStyle(fontSize: 12.0),
                  ),
                ),
                onTap: () {
                  Navigator.pop(context, '$nome');
                },
              ));
        });
  }
}
