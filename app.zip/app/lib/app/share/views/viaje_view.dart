import 'package:flutter/material.dart';
import 'package:seapp/app/domain/models/viaje_model.dart';
import 'package:seapp/app/share/controllers/viaje_controller.dart';
import 'package:seapp/app/share/views/viaje_edit_view.dart';

class ViajeView extends StatefulWidget {
  @override
  _ViajeViewState createState() => _ViajeViewState();
}

class _ViajeViewState extends State<ViajeView> {
  ViajeController con = ViajeController();

  @override
  Widget build(BuildContext context) {
    return Container(
      width: MediaQuery.of(context).size.width,
      height: MediaQuery.of(context).size.height,
      child: FutureBuilder(
          future: con.load(),
          builder: (context, snapshot) {
            if (snapshot.hasData) {
              return list(snapshot.data);
            }
            return Center(
              child: CircularProgressIndicator(),
            );
          }),
    );
  }

  list(List<ViajeModel> list) {
    return ListView.builder(
        itemCount: list.length,
        itemBuilder: (context, index) {
          ViajeModel viaje = list[index];
          return Padding(
            padding: EdgeInsets.fromLTRB(5, 2, 5, 2),
            child: Card(
              child: Stack(
                children: [
                  Center(
                    child: Image.asset(
                      "assets/images/loc.png",
                      width: 45,
                      height: 45,
                      color: Color.fromRGBO(0, 0, 0, 0.1),
                    ),
                  ),
                  Column(
                    children: [
                      Padding(
                        padding: EdgeInsets.only(top: 5),
                        child: Container(
                          width: MediaQuery.of(context).size.width - 40,
                          child: Text(
                            "${viaje.id} \n Origem: ${viaje.origem} \n Destino: ${viaje.destino} \n Percurso: ${viaje.percurso}",
                            style: TextStyle(fontSize: 12.0),
                            textAlign: TextAlign.start,
                          ),
                        ),
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          IconButton(
                            icon: const Icon(Icons.search),
                            onPressed: () {
                              //Ver
                              //Navigator.push(context, null);
                            },
                            iconSize: 18.0,
                            color: Color.fromRGBO(0, 0, 255, 1),
                          ),
                          IconButton(
                            icon: const Icon(Icons.mode_edit),
                            onPressed: () => setState(() async {
                              //Editar
                              String result = await Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) =>
                                          ViajeEditView(viaje: viaje)));
                              if (result == 'save') {
                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(
                                    content: Text("Salvo com sucesso !!!"),
                                  ),
                                );
                              }
                            }),
                            iconSize: 18.0,
                            color: Color.fromRGBO(255, 255, 0, 1),
                          ),
                          IconButton(
                            icon: const Icon(Icons.delete_forever),
                            onPressed: () => setState(() async {
                              //Deletar
                              await con.delete(viaje);
                            }),
                            iconSize: 18.0,
                            color: Color.fromRGBO(255, 0, 0, 1),
                          ),
                        ],
                      ),
                    ],
                  ),
                ],
              ),
            ),
          );
        });
  }
}
