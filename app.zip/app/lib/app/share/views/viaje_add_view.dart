import 'package:flutter/material.dart';
import 'package:seapp/app/domain/models/viaje_model.dart';
import 'package:seapp/app/share/controllers/viaje_controller.dart';
import 'package:seapp/app/share/views/viaje_add_list_view.dart';

class ViajeAddView extends StatefulWidget {
  final ViajeController con = ViajeController();
  final ViajeModel viaje = ViajeModel();

  @override
  _ViajeAddViewState createState() => _ViajeAddViewState();
}

class _ViajeAddViewState extends State<ViajeAddView> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Viaje - Novo"),
      ),
      body: Container(
        width: MediaQuery.of(context).size.width,
        height: MediaQuery.of(context).size.height,
        child: ListView(
          children: [
            Padding(
                padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 3),
                child: Row(
                  children: [
                    TextField(
                      controller:
                          TextEditingController(text: widget.viaje.origem),
                      onChanged: (text) => widget.viaje.origem = text,
                      keyboardType: TextInputType.name,
                      decoration: InputDecoration(
                        labelText: "Origem:",
                        border: OutlineInputBorder(),
                      ),
                    ),
                    IconButton(
                      icon: const Icon(Icons.search),
                      onPressed: () => setState(() async {
                        widget.viaje.origem = await select(context);
                      }),
                      iconSize: 18.0,
                      color: Color.fromRGBO(0, 0, 0, 1),
                    ),
                  ],
                )),
            Padding(
                padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 3),
                child: Row(
                  children: [
                    TextField(
                      controller:
                          TextEditingController(text: widget.viaje.destino),
                      onChanged: (text) => widget.viaje.destino = text,
                      keyboardType: TextInputType.name,
                      decoration: InputDecoration(
                        labelText: "Destino:",
                        border: OutlineInputBorder(),
                      ),
                    ),
                    IconButton(
                      icon: const Icon(Icons.search),
                      onPressed: () => setState(() async {
                        widget.viaje.origem = await select(context);
                      }),
                      iconSize: 18.0,
                      color: Color.fromRGBO(0, 0, 0, 1),
                    ),
                  ],
                )),
          ],
        ),
      ),
      floatingActionButton: CircleAvatar(
        radius: 25,
        backgroundColor: Colors.indigo,
        child: IconButton(
            icon: Icon(Icons.save),
            color: Colors.white,
            onPressed: () {
              String valid = widget.con.valid(widget.viaje);
              if (valid.isEmpty) {
                widget.con.save(widget.viaje);
                Navigator.pop(context, 'new');
              } else {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text("$valid"),
                  ),
                );
              }
            }),
      ),
    );
  }

  Future<String> select(BuildContext context) async {
    return await Navigator.push(
        context, MaterialPageRoute(builder: (context) => ViajeAddListView()));
  }
}
