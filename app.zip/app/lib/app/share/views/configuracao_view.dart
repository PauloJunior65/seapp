import 'package:flutter/material.dart';
import 'package:hidden_drawer_menu/hidden_drawer_menu.dart';

class ConfiguracaoView extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      width: MediaQuery.of(context).size.width,
      height: MediaQuery.of(context).size.height,
      child: ListView(
        children: [
          Text(
            "Screen 1",
            style: TextStyle(color: Colors.black, fontSize: 30.0),
          ),
          RaisedButton(
            child: Text('Toggle'),
            onPressed: () {
              SimpleHiddenDrawerController.of(context).toggle();
            },
          )
        ],
      ),
    );
  }
}
