import 'package:seapp/app/domain/models/viaje_model.dart';
import 'package:seapp/app/domain/repositories/percurso_repository.dart';
import 'package:seapp/app/domain/repositories/viaje_repository.dart';

class ViajeController {
  ViajeRepository rep = ViajeRepository();

  Future<List<ViajeModel>> load() async {
    List<ViajeModel> list = await rep.all();
    // List<ViajeModel> list = List.generate(20, (i) {
    //   return ViajeModel(
    //     id: i,
    //     origem: "Origem $i",
    //     destino: "Destino $i",
    //   );
    // });
    list.forEach((element) async {
      element.percurso = await PercursoRepository().countViaje(element.id);
    });
    return list;
  }

  Future<List<ViajeModel>> loadBarco() async {
    List<ViajeModel> list = await rep.all();
    // List<ViajeModel> list = List.generate(20, (i) {
    //   return ViajeModel(
    //     id: i,
    //     origem: "Origem $i",
    //     destino: "Destino $i",
    //   );
    // });
    list.forEach((element) async {
      element.barcoId = await PercursoRepository().listBarcoId(element.id);
    });
    return list;
  }

  Future<List<String>> listNomes() async {
    List<ViajeModel> list = await rep.all();
    List<String> nomes = [];
    list.forEach((element) {
      if (!nomes.contains(element.origem)) {
        nomes.add(element.origem);
      }
      if (!nomes.contains(element.destino)) {
        nomes.add(element.destino);
      }
    });
    nomes.sort();
    return nomes;
  }

  String valid(ViajeModel model) {
    String tx = "";
    if (model.origem.isEmpty) tx += "Sem Origem na Viaje";
    if (model.destino.isEmpty) tx += "\nSem Destino na Viaje";
    return tx;
  }

  save(ViajeModel model) async {
    await rep.save(model);
  }

  delete(ViajeModel model) async {
    await rep.delete(model.id);
  }
}
