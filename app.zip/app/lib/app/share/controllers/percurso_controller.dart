import 'package:seapp/app/domain/models/barco_model.dart';
import 'package:seapp/app/domain/models/percurso_model.dart';
import 'package:seapp/app/domain/models/ponto_model.dart';
import 'package:seapp/app/domain/models/viaje_model.dart';
import 'package:seapp/app/domain/repositories/percurso_repository.dart';
import 'package:seapp/app/share/controllers/barco_controller.dart';
import 'package:seapp/app/share/controllers/ponto_controller.dart';
import 'package:seapp/app/share/controllers/viaje_controller.dart';

class PercursoController {
  PercursoRepository rep = PercursoRepository();

  Future<List<PercursoModel>> load() async {
    List<PercursoModel> list = await rep.all();
    // return List.generate(20, (i) {
    //   return PercursoModel(
    //     id: i,
    //     nome: "Nome $i",
    //     potencia: i + 0.5,
    //     peso: i + 0.8,
    //     tipo: "Tipo $i",
    //     capacidade: i * 3,
    //   );
    // });
    List<BarcoModel> barcos = await BarcoController().load();
    List<ViajeModel> viajes = await ViajeController().load();
    List<PontoModel> pontos = await PontoController().load();
    list.forEach((element) {
      for (BarcoModel barco in barcos) {
        if (element.barcoId == barco.id) {
          element.barco = barco;
          break;
        }
      }
      for (ViajeModel viaje in viajes) {
        if (element.viajeId == viaje.id) {
          element.viaje = viaje;
          break;
        }
      }
      List<PontoModel> listpontos = [];
      for (PontoModel ponto in pontos) {
        if (element.id == ponto.percursoId) {
          listpontos.add(ponto);
        }
      }
      element.pontos = listpontos;
    });
    return list;
  }

  Future<Map<String, dynamic>> loadBarcoViaje() async {
    final Map<String, dynamic> data = Map<String, dynamic>();
    data['barco'] = await BarcoController().load();
    data['viaje'] = await ViajeController().loadBarco();
    return data;
  }

  List<ViajeModel> listViaje(List<ViajeModel> list, PercursoModel percurso) {
    List<ViajeModel> result = [];
    if (percurso.barco != null) {
      List<ViajeModel> l1 = [];
      List<ViajeModel> l2 = [];
      list.forEach((element) {
        if (element.barcoId.contains(percurso.barco.id)) {
          l1.add(element);
        } else {
          l2.add(element);
        }
      });
      l1.sort((a, b) => sortViaje(a, b));
      l2.sort((a, b) => sortViaje(a, b));
    }
    return result;
  }

  int sortViaje(ViajeModel a, ViajeModel b) {
    int nome = a.origem.compareTo(b.origem);
    if (nome != 0) return nome;
    return a.destino.compareTo(b.destino);
  }

  String valid(PercursoModel model) {
    String tx = "";
    if (model.barcoId == 0) tx += "Sem Barco no Percurso";
    if (model.viajeId == 0) tx += "\nSem Viaje no Percurso";
    return tx;
  }

  save(PercursoModel model) async {
    await rep.save(model);
  }
}
