import 'package:seapp/app/domain/models/percurso_model.dart';
import 'package:seapp/app/domain/models/ponto_model.dart';
import 'package:seapp/app/domain/models/viaje_model.dart';
import 'package:seapp/app/share/controllers/barco_controller.dart';
import 'package:seapp/app/share/controllers/ponto_controller.dart';
import 'package:seapp/app/share/controllers/percurso_controller.dart';
import 'package:seapp/app/share/controllers/viaje_controller.dart';
import 'package:geolocator/geolocator.dart';

class PercursoViewController {
  PercursoController conPer = PercursoController();
  PontoController conPon = PontoController();

  PercursoModel percurso = PercursoModel();
  DateTime datetime = DateTime.now();
  List<double> velocidade = [];

  // // torna esta classe singleton
  // PercursoViewController._privateConstructor();
  // static final PercursoViewController _instance =
  //     PercursoViewController._privateConstructor();
  // factory PercursoViewController() {
  //   return _instance;
  // }

  Future<Map<String, dynamic>> load() async {
    final Map<String, dynamic> data = Map<String, dynamic>();
    data['barco'] = await BarcoController().load();
    data['viaje'] = await ViajeController().loadBarco();
    percurso.pontos = [];
    return data;
  }

  List<ViajeModel> listViaje(List<ViajeModel> list) {
    List<ViajeModel> result = [];
    if (percurso.barco != null) {
      List<ViajeModel> l1 = [];
      List<ViajeModel> l2 = [];
      list.forEach((element) {
        if (element.barcoId.contains(percurso.barco.id)) {
          l1.add(element);
        } else {
          l2.add(element);
        }
      });
      l1.sort((a, b) => sortViaje(a, b));
      l2.sort((a, b) => sortViaje(a, b));
    }
    return result;
  }

  int sortViaje(ViajeModel a, ViajeModel b) {
    int nome = a.origem.compareTo(b.origem);
    if (nome != 0) return nome;
    return a.destino.compareTo(b.destino);
  }

  String tempo() {
    DateTime atual = DateTime.now();
    //atual.add(Duration(seconds: 200));
    return tempoDuration(datetime.difference(atual));
  }

  String tempoDuration(Duration duration) {
    int hour = duration.inHours;
    int minute = duration.inMinutes - (hour * 60);
    int second = duration.inSeconds - (minute * 60);
    return "$hour:$minute:$second";
  }

  Future<String> isPermission() async {
    bool serviceEnabled;
    LocationPermission permission;

    serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      return Future.error('Location services are disabled.');
    }

    permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.deniedForever) {
      return Future.error(
          'Location permissions are permantly denied, we cannot request permissions.');
    }

    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission != LocationPermission.whileInUse &&
          permission != LocationPermission.always) {
        return Future.error(
            'Location permissions are denied (actual value: $permission).');
      }
    }

    return "";
  }

  Future<Position> getPosition() async {
    return await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.bestForNavigation);
  }

  update(bool add) async {
    Position p = await getPosition();
    percurso.velocidade = p.speed;
    if (add) {
      if (p.speed > 1) velocidade.add(p.speed);
      percurso.pontos.add(PontoModel(
          latitude: p.latitude,
          longitude: p.longitude,
          datetime: DateTime.now().toString()));
    }
    if (percurso.pontos.length >= 2) {
      percurso.distancia = 0;
      for (var i = 1; i < percurso.pontos.length; i++) {
        PontoModel a = percurso.pontos[i - 1];
        PontoModel b = percurso.pontos[i];
        percurso.distancia += Geolocator.distanceBetween(
            a.latitude, a.longitude, b.latitude, b.longitude);
        if (i == percurso.pontos.length - 1) {
          percurso.distancia += Geolocator.distanceBetween(
              b.latitude, b.longitude, p.latitude, p.longitude);
        }
      }
    }
  }

  calcular() {
    if (percurso.pontos.length >= 2) {
      percurso.distancia = 0;
      Duration tempo = Duration();
      for (var i = 1; i < percurso.pontos.length; i++) {
        PontoModel a = percurso.pontos[i - 1];
        PontoModel b = percurso.pontos[i];
        DateTime ta = DateTime.parse(a.datetime);
        DateTime tb = DateTime.parse(b.datetime);
        tempo = Duration(
            microseconds:
                tempo.inMicroseconds + ta.difference(tb).inMicroseconds);
        percurso.distancia += Geolocator.distanceBetween(
            a.latitude, a.longitude, b.latitude, b.longitude);
      }
      percurso.tempo = tempo.inSeconds;
      double somavelocidade = 0;
      velocidade.forEach((element) => somavelocidade += element);
      percurso.velocidade = somavelocidade / velocidade.length;
      percurso.combustivel = percurso.barco.combustivel *
          (tempo.inMicroseconds / Duration.millisecondsPerHour);
    }
  }
}
