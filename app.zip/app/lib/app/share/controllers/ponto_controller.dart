import 'package:seapp/app/domain/models/ponto_model.dart';
import 'package:seapp/app/domain/repositories/ponto_repository.dart';

class PontoController {
  PontoRepository rep = PontoRepository();

  Future<List<PontoModel>> load() async {
    List<PontoModel> list = await rep.all();
    // return List.generate(20, (i) {
    //   return PontoModel(
    //     id: i,
    //     nome: "Nome $i",
    //     potencia: i + 0.5,
    //     peso: i + 0.8,
    //     tipo: "Tipo $i",
    //     capacidade: i * 3,
    //   );
    // });
    return list;
  }

  String valid(PontoModel model) {
    String tx = "";
    return tx;
  }

  save(PontoModel model) async {
    await rep.save(model);
  }
}
