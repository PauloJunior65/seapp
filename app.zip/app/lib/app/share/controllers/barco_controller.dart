import 'package:seapp/app/domain/models/barco_model.dart';
import 'package:seapp/app/domain/repositories/barco_repository.dart';
import 'package:seapp/app/domain/repositories/percurso_repository.dart';

class BarcoController {
  BarcoRepository rep = BarcoRepository();

  Future<List<BarcoModel>> load() async {
    List<BarcoModel> list = await rep.all();
    // return List.generate(20, (i) {
    //   return BarcoModel(
    //     id: i,
    //     nome: "Nome $i",
    //     potencia: i + 0.5,
    //     peso: i + 0.8,
    //     tipo: "Tipo $i",
    //     capacidade: i * 3,
    //   );
    // });
    list.forEach((element) async {
      element.percurso = await PercursoRepository().countBarco(element.id);
    });
    return list;
  }

  String valid(BarcoModel model) {
    String tx = "";
    if (model.nome.isEmpty) tx += "Sem Nome de Embarcação";
    if (model.tipo.isEmpty) tx += "\nSem Tipo de Embarcação";
    if (model.potencia <= 0) tx += "\nPotencia do Motor Invalido";
    if (model.peso <= 0) tx += "\nPeso da Embarcação Invalido";
    return tx;
  }

  save(BarcoModel model) async {
    await rep.save(model);
  }

  delete(BarcoModel model) async {
    await rep.delete(model.id);
  }
}
