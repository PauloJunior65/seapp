import 'dart:async';
import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

class DatabaseRepository {
  static final _databaseName = "seapp.db";
  static final _databaseVersion = 1;

  // torna esta classe singleton
  DatabaseRepository._privateConstructor();
  static final DatabaseRepository _instance =
      DatabaseRepository._privateConstructor();
  factory DatabaseRepository() {
    return _instance;
  }

  Future<Database> database() async {
    return openDatabase(
      join(await getDatabasesPath(), _databaseName),
      onCreate: (db, version) async {
        await db.execute(
            "CREATE TABLE barco (id INTEGER PRIMARY KEY AUTOINCREMENT, nome TEXT, potencia REAL, peso REAL, tipo TEXT, combustivel REAL);");
        await db.execute(
            "CREATE TABLE viaje (id INTEGER PRIMARY KEY AUTOINCREMENT, origem TEXT, destino TEXT);");
        await db.execute(
            "CREATE TABLE percurso (id INTEGER PRIMARY KEY AUTOINCREMENT, barco_id INTEGER REFERENCES barco (id) ON DELETE CASCADE ON UPDATE CASCADE, viaje_id INTEGER REFERENCES viaje (id) ON DELETE CASCADE ON UPDATE CASCADE, tempo TEXT, distancia REAL, velocidade REAL, combustivel REAL, crianca INTEGER, adulto INTEGER);");
        await db.execute(
            "CREATE TABLE ponto (id INTEGER PRIMARY KEY AUTOINCREMENT, percurso_id INTEGER REFERENCES percurso (id) ON DELETE CASCADE ON UPDATE CASCADE, datetime TEXT, latitude REAL, longitude REAL);");
        return;
      },
      version: _databaseVersion,
    );
  }

  // métodos Helper
  //----------------------------------------------------
  // Insere uma linha no banco de dados onde cada chave
  // no Map é um nome de coluna e o valor é o valor da coluna.
  // O valor de retorno é o id da linha inserida.
  Future<int> insert(String table, Map<String, dynamic> row) async {
    row.remove(row.keys.first);
    final Database db = await database();
    return await db.insert(
      table,
      row,
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  // Todas as linhas são retornadas como uma lista de mapas, onde cada mapa é
  // uma lista de valores-chave de colunas.
  Future<List<Map<String, dynamic>>> queryAllRows(String table) async {
    final Database db = await database();
    return await db.query(table);
  }

  Future<List<Map<String, dynamic>>> queryRAW(String table, String raw) async {
    final Database db = await database();
    return await db.rawQuery('SELECT * FROM $table $raw');
  }

  // Todos os métodos : inserir, consultar, atualizar e excluir,
  // também podem ser feitos usando  comandos SQL brutos.
  // Esse método usa uma consulta bruta para fornecer a contagem de linhas.
  Future<int> queryRowCount(String table) async {
    final Database db = await database();
    return Sqflite.firstIntValue(
        await db.rawQuery('SELECT COUNT(*) FROM $table'));
  }

  Future<int> queryRowCountRaw(String table, String where) async {
    final Database db = await database();
    return Sqflite.firstIntValue(
        await db.rawQuery('SELECT COUNT(*) FROM $table $where'));
  }

  // Assumimos aqui que a coluna id no mapa está definida. Os outros
  // valores das colunas serão usados para atualizar a linha.
  Future<int> update(
      String table, String columnId, Map<String, dynamic> row) async {
    int id = row[columnId];
    final Database db = await database();
    return await db.update(
      table,
      row,
      where: "$columnId = ?",
      whereArgs: [id],
    );
  }

  // Exclui a linha especificada pelo id. O número de linhas afetadas é
  // retornada. Isso deve ser igual a 1, contanto que a linha exista.
  Future<int> delete(String table, String columnId, int id) async {
    final Database db = await database();
    return await db.delete(
      table,
      where: "$columnId = ?",
      whereArgs: [id],
    );
  }
}
