import 'package:seapp/app/domain/models/barco_model.dart';
import 'package:seapp/app/domain/repositories/database_repository.dart';

class BarcoRepository {
  static String table = "barco";
  static String columnId = "id";
  DatabaseRepository db = DatabaseRepository();

  // torna esta classe singleton
  BarcoRepository._privateConstructor();
  static final BarcoRepository _instance =
      BarcoRepository._privateConstructor();
  factory BarcoRepository() {
    return _instance;
  }

  Future<bool> save(BarcoModel obj) async {
    return (obj.id == 0) ? await inserir(obj) : await update(obj);
  }

  Future<bool> inserir(BarcoModel obj) async {
    final id = await db.insert(table, obj.toMap());
    obj.id = id;
    return !id.isNaN && id > 0;
  }

  Future<List<BarcoModel>> all() async {
    final rows = await db.queryAllRows(table);
    return List.generate(rows.length, (i) {
      return BarcoModel.fromMap(rows[i]);
    });
  }

  Future<bool> update(BarcoModel obj) async {
    final rows = await db.update(table, columnId, obj.toMap());
    return rows > 0;
  }

  Future<bool> delete(int id) async {
    final rows = await db.delete(table, columnId, id);
    return rows > 0;
  }

  Future<int> count() async {
    return await db.queryRowCount(table);
  }

  Future<List<BarcoModel>> raw(String raw) async {
    final rows = await db.queryRAW(table, raw);
    return List.generate(rows.length, (i) {
      return BarcoModel.fromMap(rows[i]);
    });
  }
}
