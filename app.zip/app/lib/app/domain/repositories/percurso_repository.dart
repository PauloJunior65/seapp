import 'package:seapp/app/domain/models/percurso_model.dart';
import 'package:seapp/app/domain/repositories/database_repository.dart';

class PercursoRepository {
  static String table = "percurso";
  static String columnId = "id";
  DatabaseRepository db = DatabaseRepository();

  // torna esta classe singleton
  PercursoRepository._privateConstructor();
  static final PercursoRepository _instance =
      PercursoRepository._privateConstructor();
  factory PercursoRepository() {
    return _instance;
  }

  Future<bool> save(PercursoModel obj) async {
    return (obj.id == 0) ? await inserir(obj) : await update(obj);
  }

  Future<bool> inserir(PercursoModel obj) async {
    final id = await db.insert(table, obj.toMap());
    obj.id = id;
    return !id.isNaN && id > 0;
  }

  Future<List<PercursoModel>> all() async {
    final rows = await db.queryAllRows(table);
    return List.generate(rows.length, (i) {
      return PercursoModel.fromMap(rows[i]);
    });
  }

  Future<bool> update(PercursoModel obj) async {
    final rows = await db.update(table, columnId, obj.toMap());
    return rows > 0;
  }

  Future<bool> delete(int id) async {
    final rows = await db.delete(table, columnId, id);
    return rows > 0;
  }

  Future<int> count() async {
    return await db.queryRowCount(table);
  }

  Future<int> countViaje(int viaje) async {
    return await db.queryRowCountRaw(table, "WHERE viajeId = $viaje");
  }

  Future<int> countBarco(int barco) async {
    return await db.queryRowCountRaw(table, "WHERE barcoId = $barco");
  }

  Future<List<int>> listBarcoId(int viaje) async {
    final rows = await db.queryRAW(table, "WHERE viajeId = $viaje");
    return List.generate(rows.length, (i) {
      return PercursoModel.fromMap(rows[i]).barcoId;
    });
  }

  Future<List<PercursoModel>> raw(String raw) async {
    final rows = await db.queryRAW(table, raw);
    return List.generate(rows.length, (i) {
      return PercursoModel.fromMap(rows[i]);
    });
  }
}
