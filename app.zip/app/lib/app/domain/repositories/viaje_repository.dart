import 'package:seapp/app/domain/models/viaje_model.dart';
import 'package:seapp/app/domain/repositories/database_repository.dart';

class ViajeRepository {
  static String table = "viaje";
  static String columnId = "id";
  DatabaseRepository db = DatabaseRepository();

  // torna esta classe singleton
  ViajeRepository._privateConstructor();
  static final ViajeRepository _instance =
      ViajeRepository._privateConstructor();
  factory ViajeRepository() {
    return _instance;
  }

  Future<bool> save(ViajeModel obj) async {
    return (obj.id == 0) ? await inserir(obj) : await update(obj);
  }

  Future<bool> inserir(ViajeModel obj) async {
    final id = await db.insert(table, obj.toMap());
    obj.id = id;
    return !id.isNaN && id > 0;
  }

  Future<List<ViajeModel>> all() async {
    final rows = await db.queryAllRows(table);
    return List.generate(rows.length, (i) {
      return ViajeModel.fromMap(rows[i]);
    });
  }

  Future<bool> update(ViajeModel obj) async {
    final rows = await db.update(table, columnId, obj.toMap());
    return rows > 0;
  }

  Future<bool> delete(int id) async {
    final rows = await db.delete(table, columnId, id);
    return rows > 0;
  }

  Future<int> count() async {
    return await db.queryRowCount(table);
  }

  Future<List<ViajeModel>> raw(String raw) async {
    final rows = await db.queryRAW(table, raw);
    return List.generate(rows.length, (i) {
      return ViajeModel.fromMap(rows[i]);
    });
  }
}
