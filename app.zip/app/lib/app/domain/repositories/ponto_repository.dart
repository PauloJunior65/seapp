import 'package:seapp/app/domain/models/ponto_model.dart';
import 'package:seapp/app/domain/repositories/database_repository.dart';

class PontoRepository {
  static String table = "ponto";
  static String columnId = "id";
  DatabaseRepository db = DatabaseRepository();

  // torna esta classe singleton
  PontoRepository._privateConstructor();
  static final PontoRepository _instance =
      PontoRepository._privateConstructor();
  factory PontoRepository() {
    return _instance;
  }

  Future<bool> save(PontoModel obj) async {
    return (obj.id == 0) ? await inserir(obj) : await update(obj);
  }

  Future<bool> inserir(PontoModel obj) async {
    final id = await db.insert(table, obj.toMap());
    obj.id = id;
    return !id.isNaN && id > 0;
  }

  Future<List<PontoModel>> all() async {
    final rows = await db.queryAllRows(table);
    return List.generate(rows.length, (i) {
      return PontoModel.fromMap(rows[i]);
    });
  }

  Future<bool> update(PontoModel obj) async {
    final rows = await db.update(table, columnId, obj.toMap());
    return rows > 0;
  }

  Future<bool> delete(int id) async {
    final rows = await db.delete(table, columnId, id);
    return rows > 0;
  }

  Future<int> count() async {
    return await db.queryRowCount(table);
  }

  Future<List<PontoModel>> raw(String raw) async {
    final rows = await db.queryRAW(table, raw);
    return List.generate(rows.length, (i) {
      return PontoModel.fromMap(rows[i]);
    });
  }
}
