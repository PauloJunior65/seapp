import 'package:ai/ai.dart';

class Network {
  MLP n;

  Network.init() {
    n = MLP.from(Structure());
  }

  setDataBase(input, target) {}
}
