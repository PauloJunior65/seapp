class ViajeModel {
  int id;
  String origem;
  String destino;
  //------------------
  int percurso;
  List<int> barcoId;

  ViajeModel({this.id = 0, this.origem = "", this.destino = ""});

  ViajeModel.fromMap(Map<String, dynamic> json) {
    id = json['id'];
    origem = json['origem'];
    destino = json['destino'];
  }

  Map<String, dynamic> toMap() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['origem'] = this.origem;
    data['destino'] = this.destino;
    return data;
  }

  @override
  String toString() {
    return 'Viaje{id: $id, origem: $origem, destino: $destino}';
  }
}
