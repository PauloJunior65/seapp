class PontoModel {
  int id;
  int percursoId;
  String datetime;
  double latitude;
  double longitude;

  PontoModel(
      {this.id = 0,
      this.percursoId = 0,
      this.datetime = "",
      this.latitude = 0,
      this.longitude = 0});

  PontoModel.fromMap(Map<String, dynamic> json) {
    id = json['id'];
    percursoId = json['percurso_id'];
    datetime = json['datetime'];
    latitude = json['latitude'];
    longitude = json['longitude'];
  }

  Map<String, dynamic> toMap() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['percurso_id'] = this.percursoId;
    data['datetime'] = this.datetime;
    data['latitude'] = this.latitude;
    data['longitude'] = this.longitude;
    return data;
  }

  @override
  String toString() {
    return 'Ponto{id: $id, percurso_id: $percursoId, datetime: $datetime, latitude: $latitude, longitude: $longitude}';
  }
}
