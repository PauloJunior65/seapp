class BarcoModel {
  int id;
  String nome;
  double potencia;
  double peso;
  String tipo;
  double combustivel;
  //----------------
  int percurso;

  BarcoModel(
      {this.id = 0,
      this.nome = "",
      this.potencia = 0,
      this.peso = 0,
      this.tipo = "",
      this.combustivel = 0});

  BarcoModel.fromMap(Map<String, dynamic> map) {
    id = map['id'];
    nome = map['nome'];
    potencia = map['potencia'];
    peso = map['peso'];
    tipo = map['tipo'];
    combustivel = map['combustivel'];
  }

  Map<String, dynamic> toMap() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['nome'] = this.nome;
    data['potencia'] = this.potencia;
    data['peso'] = this.peso;
    data['tipo'] = this.tipo;
    data['combustivel'] = this.combustivel;
    return data;
  }

  @override
  String toString() {
    return 'Barco{id: $id, nome: $nome, potencia: $potencia, peso: $peso, tipo: $tipo, combustivel: $combustivel}';
  }
}
