import 'package:seapp/app/domain/models/barco_model.dart';
import 'package:seapp/app/domain/models/ponto_model.dart';
import 'package:seapp/app/domain/models/viaje_model.dart';

class PercursoModel {
  int id;
  int barcoId;
  int viajeId;
  int tempo;
  double distancia;
  double velocidade;
  double combustivel;
  int crianca;
  int adulto;
  //-----------------
  BarcoModel barco;
  ViajeModel viaje;
  List<PontoModel> pontos;

  PercursoModel(
      {this.id = 0,
      this.barcoId = 0,
      this.viajeId = 0,
      this.tempo = 0,
      this.distancia = 0,
      this.velocidade = 0,
      this.combustivel = 0,
      this.crianca = 0,
      this.adulto = 0});

  PercursoModel.fromMap(Map<String, dynamic> json) {
    id = json['id'];
    barcoId = json['barco_id'];
    viajeId = json['viaje_id'];
    tempo = json['tempo'];
    distancia = json['distancia'];
    velocidade = json['velocidade'];
    combustivel = json['combustivel'];
    crianca = json['crianca'];
    adulto = json['adulto'];
  }

  Map<String, dynamic> toMap() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['barco_id'] = this.barcoId;
    data['viaje_id'] = this.viajeId;
    data['tempo'] = this.tempo;
    data['distancia'] = this.distancia;
    data['velocidade'] = this.velocidade;
    data['combustivel'] = this.combustivel;
    data['crianca'] = this.crianca;
    data['adulto'] = this.adulto;
    return data;
  }

  @override
  String toString() {
    return 'Percurso{id: $id, barco_id: $barcoId, viaje_id: $viajeId, tempo: $tempo, distancia: $distancia, velocidade: $velocidade, combustivel: $combustivel, criaca: $crianca, adulto: $adulto}';
  }
}
