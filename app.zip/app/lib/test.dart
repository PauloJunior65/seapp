import 'package:seapp/app/domain/models/barco_model.dart';
import 'package:seapp/app/domain/models/percurso_model.dart';
import 'package:seapp/app/domain/models/ponto_model.dart';
import 'package:seapp/app/domain/models/viaje_model.dart';
import 'package:seapp/app/domain/repositories/barco_repository.dart';
import 'package:seapp/app/domain/repositories/percurso_repository.dart';
import 'package:seapp/app/domain/repositories/ponto_repository.dart';
import 'package:seapp/app/domain/repositories/viaje_repository.dart';

class TesteMain {
  static repository() async {
    print("Repositories e Models");
    BarcoRepository repBar = BarcoRepository();
    ViajeRepository repVia = ViajeRepository();
    PercursoRepository repPer = PercursoRepository();
    PontoRepository repPon = PontoRepository();
    // ----------------------------
    print("Insert Repository");
    BarcoModel modelBar =
        BarcoModel(nome: "teste", tipo: "teste", peso: 200, potencia: 1.6);
    print("Barco insert: ${await repBar.save(modelBar)}");
    print(modelBar);
    ViajeModel modelVia = ViajeModel(origem: "porto1", destino: "porto2");
    print("Viaje insert: ${await repVia.save(modelVia)}");
    print(modelVia);
    PercursoModel modelPer = PercursoModel(
        barcoId: modelBar.id,
        viajeId: modelVia.id,
        combustivel: 13,
        distancia: 500,
        tempo: 24,
        velocidade: 323);
    print("Percurso insert: ${await repPer.save(modelPer)}");
    print(modelPer);
    PontoModel modelPon = PontoModel(
        percursoId: modelPer.id,
        latitude: 10,
        longitude: 10,
        datetime: "2020-01-20 18:00:00");
    print("Ponto insert: ${await repPon.save(modelPon)}");
    print(modelPon);
    // ---------------------
    print("Read Repository");
    List<BarcoModel> modelsBar = await repBar.all();
    print("Barco count: ${modelsBar.length == await repBar.count()}");
    print(modelsBar);
    List<ViajeModel> modelsvia = await repVia.all();
    print("Viaje count: ${modelsvia.length == await repVia.count()}");
    print(modelsvia);
    List<PercursoModel> modelsPer = await repPer.all();
    print("Percurso count: ${modelsPer.length == await repPer.count()}");
    print(modelsPer);
    List<PontoModel> modelsPon = await repPon.all();
    print("PontoModel count: ${modelsPon.length == await repPon.count()}");
    print(modelsPon);
    // ------------------------
    print("Updade Repository");
    modelBar.nome = "teste2";
    modelBar.tipo = "teste2";
    //modelBar.capacidade = 100;
    modelBar.peso = 300.5;
    modelBar.potencia = 2.5;
    print("Barco update: ${await repBar.save(modelBar)}");
    print(await repBar.all());
    modelVia.origem = "porto3";
    modelVia.destino = "porto4";
    print("Viaje update: ${await repVia.save(modelVia)}");
    print(await repVia.all());
    modelPer.combustivel = 30;
    modelPer.distancia = 45;
    //modelPer.emissao = 4.6;
    modelPer.tempo = 6000;
    modelPer.velocidade = 20;
    print("Percurso update: ${await repPer.save(modelPer)}");
    print(await repPer.all());
    modelPon.latitude = 30;
    modelPon.longitude = 35;
    modelPon.datetime = "2020-01-20 12:30:00";
    print("Ponto update: ${await repPon.save(modelPon)}");
    print(await repPon.all());
    // ------------------------
    print("Delete Repository");
    print("Ponto delete: ${await repPon.delete(modelPon.id)}");
    print(await repPon.all());
    print("Percurso delete: ${await repPer.delete(modelPer.id)}");
    print(await repPer.all());
    print("Viaje delete: ${await repVia.delete(modelVia.id)}");
    print(await repVia.all());
    print("Barco delete: ${await repBar.delete(modelBar.id)}");
    print(await repBar.all());
  }
}
