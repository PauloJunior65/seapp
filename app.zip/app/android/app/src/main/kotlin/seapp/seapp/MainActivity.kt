package seapp.seapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
